require(['notebook/js/codecell'], function(codecell) {
    codecell.CodeCell.options_default.highlight_modes['text/x-groovy'] = {'reg':[/^%%gremlin/]} ;
    Jupyter.notebook.events.one('kernel_ready.Kernel', function(){
        Jupyter.notebook.get_cells().map(function(cell) {
            if (cell.cell_type === 'code') {
                cell.auto_highlight();
                const config = cell.config;
                let patch = {
                    CodeCell:{
                        cm_config:{
                            smartIndent: true,
                        }
                    }
                };
                config.update(patch)
            }
        });
    });
});