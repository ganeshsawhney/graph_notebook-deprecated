from os.path import join as pjoin
from setuptools import setup, find_packages
from setupbase import (
    create_cmdclass, install_npm, ensure_targets,
    combine_commands, HERE, widgets_root
)

nb_path = pjoin(HERE, 'src', 'graph_notebook', 'widgets', 'nbextension', 'static')
lab_path = pjoin(HERE, 'src', 'graph_notebook', 'widgets', 'labextension')

js_targets = [
    pjoin(nb_path, 'index.js'),
    pjoin(HERE, 'src', 'graph_notebook', 'widgets', 'lib', 'plugin.d.ts')
]

package_data_spec = {
    'graph_notebook_widgets': [
        'nbextension/static/*.*js*',
        'labextension/*.tgz'
    ]
}

data_files_spec = [
    ('share/jupyter/nbextensions/graph_notebook_widgets',
     nb_path, '*.js*'),
    ('share/jupyter/lab/extensions', lab_path, '*.tgz'),
    ('etc/jupyter/nbconfig/notebook.d', HERE, 'graph_notebook_widgets.json')
]

cmd_class = create_cmdclass('jsdeps', package_data_spec=package_data_spec, data_files_spec=data_files_spec)
cmd_class['jsdeps'] = combine_commands(
    install_npm(widgets_root, build_cmd='build:all'),
    ensure_targets(js_targets),
)

setup(
    name="NeptuneGraphNotebook",
    version="1.0",
    packages=find_packages(where="src", exclude=("test",)),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        'gremlinpython',
        'SPARQLWrapper',
        'tornado>=4.5.1,<5',
        'requests<2.21,>=2.20.0',
        'ipywidgets>=7.5.1',
        'pandas>=1.0.3',
        'networkx>=2.4'
    ],
    package_data={
        '': ['*.ipynb', '*.html', '*.css', '*.js', '*.txt', '*.json', '*.ts', '*.css']
    },
    cmdclass=cmd_class
)