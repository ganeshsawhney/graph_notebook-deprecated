require.config({
    paths: {
        datatables: 'datatables',
    }
});