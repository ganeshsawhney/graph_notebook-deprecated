from enum import Enum

from graph_notebook.authentication.iam_credentials_provider.credentials_factory import IAMAuthCredentialsProvider


class AuthModeEnum(Enum):
    DEFAULT = "DEFAULT"
    IAM = "IAM"


class Neptune(object):
    def __init__(self,
                 host: str,
                 port: int,
                 auth_mode: AuthModeEnum = AuthModeEnum.DEFAULT,
                 iam_credentials_provider: IAMAuthCredentialsProvider = IAMAuthCredentialsProvider.ROLE,
                 ssl: bool = True):
        self.host = host
        self.port = port
        self.auth_mode = auth_mode
        self.iam_credentials_provider = iam_credentials_provider
        self.ssl = ssl
