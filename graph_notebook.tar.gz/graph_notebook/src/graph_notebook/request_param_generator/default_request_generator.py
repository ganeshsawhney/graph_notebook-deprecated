class DefaultRequestGenerator(object):
    @staticmethod
    def generate_request_params(method, action, query, host, port, protocol, headers=None):
        return {
            'method': method,
            'url': f'{protocol}://{host}:{port}/{action}',
            'headers': headers,
            'params': query,
        }

