from IPython import get_ipython

print('loading graph_notebook.magics...')
get_ipython().run_line_magic('load_ext', 'graph_notebook.magics')
