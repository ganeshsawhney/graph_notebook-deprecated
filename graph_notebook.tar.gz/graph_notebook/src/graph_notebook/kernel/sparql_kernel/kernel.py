import logging

from ipykernel.kernelbase import Kernel

from graph_notebook.gremlin.client_provider.factory import create_client_provider
from graph_notebook.magics.completers.graph_completer import SPARQL_OPTIONS
from graph_notebook.magics.graph_magic import sparql_to_html
from graph_notebook.configuration.get_config import get_config

logging.basicConfig()
logger = logging.getLogger('sparql_kernel')
logger.setLevel(logging.DEBUG)


class SparqlKernel(Kernel):
    implementation = 'SPARQL'
    implementation_version = '1.0'
    language = 'sparql'
    language_version = '0.1'
    language_info = {
        'name': 'sparql',
        'codemirror_mode': {'name': 'application/sparql-query'},
        'file_extension': '.sparql',
    }
    banner = "SPARQL kernel"

    def do_complete(self, code, cursor_pos):
        logger.setLevel(logging.DEBUG)  # Uncomment to see logs
        logger.info(f'do complete with code={code} and cursor_pos={cursor_pos}')

        try:
            last_index = code.rindex(' ')
            token = code[last_index + 1:]
            cursor_start = last_index + 1
        except:
            token = code
            cursor_start = 0

        logger.info(f'auto-completing for token={token}')

        matches = []
        for option in SPARQL_OPTIONS:
            if option.startswith(token):
                matches.append(f'{option}')

        logger.info(f'got the matches {matches}')

        content = {
            'matches': matches,
            'cursor_start': cursor_start,  # we want to keep the space
            'cursor_end': cursor_pos,
            'metadata': {},
            'status': 'ok'
        }

        return content

    def do_execute(self, code, silent, store_history=True,
                   user_expressions=None, allow_stdin=False):
        logger.setLevel(logging.DEBUG)  # Uncomment to see logs
        if code != '':
            try:
                config = get_config()
                if config['auth_mode'] != 'IAM':
                    config['auth_mode'] = 'SPARQL'
                logger.info(f'got config with auth_mode set to {config["auth_mode"]}')
                client_provider = create_client_provider(config['auth_mode'], config['iam_credentials_provider_type'])
                raw_html = sparql_to_html(code, config['host'], config['port'], config['ssl'], client_provider)
                display_content = {
                    'data': {
                        'text/html': raw_html,
                        'text/plain': 'text response'
                    },
                    'metadata': {
                        'isolated': True
                    }
                }
                self.send_response(self.iopub_socket, 'display_data', display_content)
            except Exception as e:
                self.send_response(self.iopub_socket, 'error', e)

        return {
            'status': 'ok',
            # The base class increments the execution count
            'execution_count': self.execution_count,
            'payload': [],
            'user_expressions': {},
        }


if __name__ == '__main__':
    from ipykernel.kernelapp import IPKernelApp
    IPKernelApp.launch_instance(kernel_class=SparqlKernel)
