import os
static_path = os.path.expanduser('~/neptune_workbench/static/')
c.NotebookApp.extra_static_paths = [static_path]
