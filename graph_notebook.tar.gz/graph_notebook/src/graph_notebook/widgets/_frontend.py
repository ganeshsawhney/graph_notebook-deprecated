"""
Information about the frontend package of the widgets.
"""

module_name = "graph_notebook_widgets"
module_version = "0.1.0"
