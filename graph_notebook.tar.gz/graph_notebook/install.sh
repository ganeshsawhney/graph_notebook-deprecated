#!/bin/bash

source activate JupyterSystemEnv

# copy to home directory
cp -ar /tmp/graph_notebook/ ~/

cd ~/graph_notebook || exit
echo "copying to relevant directories from $(pwd)"

echo "copying jupyter custom css and js"
mkdir -p ~/.jupyter/custom/
cp -r ~/graph_notebook/src/graph_notebook/jupyter_profile/jupyter/custom/* ~/.jupyter/custom/
cat src/graph_notebook/jupyter_profile/jupyter_notebook_config.py >>~/.jupyter/jupyter_notebook_config.py

site_packages=$(python -c 'import site; print(site.getsitepackages()[0])')
cp -r src/graph_notebook/static_resources/* "${site_packages}/notebook/static"

echo "intalling python dependencies..."
pip install -r ~/graph_notebook/requirements.txt --upgrade
pip install --upgrade ~/graph_notebook
pip install --upgrade tornado==4.5.1
pip install --upgrade jupyter_contrib_nbextensions

# taken from https://aws.amazon.com/blogs/apn/building-a-data-processing-and-training-pipeline-with-amazon-sagemaker/
echo "install js dependencies"
PATH=/home/ec2-user/anaconda3/envs/JupyterSystemEnv/bin/:$PATH
pushd . || exit
cd ${site_packages}/graph_notebook/widgets || exit
npm ci
npm run build:all
popd || exit

pushd .
echo "copying nbextensions..."
cd ~/graph_notebook/src/graph_notebook/nbextensions || exit
jupyter nbextension install neptune_menu --sys-prefix
jupyter nbextension enable neptune_menu/main

jupyter nbextension install sparql_syntax --sys-prefix
jupyter nbextension enable sparql_syntax/main

jupyter nbextension install gremlin_syntax --sys-prefix
jupyter nbextension enable gremlin_syntax/main
popd || exit

python3 -m ipykernel install --sys-prefix --name python3 --display-name "Python 3"

jupyter nbextension install --py --sys-prefix graph_notebook.widgets
jupyter nbextension enable  --py --sys-prefix graph_notebook.widgets

source ~/.bashrc || exit
HOST=${GRAPH_NOTEBOOK_HOST}
PORT=${GRAPH_NOTEBOOK_PORT}
AUTH_MODE=${GRAPH_NOTEBOOK_AUTH_MODE}
SSL=${GRAPH_NOTEBOOK_SSL}
IAM_CREDENTIALS_PROVIDER=${GRAPH_NOTEBOOK_IAM_PROVIDER}
LOAD_FROM_S3_ARN=${NEPTUNE_LOAD_FROM_S3_ROLE_ARN}

if [[ ${SSL} -eq "" ]]; then
  SSL="True"
fi

echo "Creating config with
HOST:                       ${HOST}
PORT:                       ${PORT}
AUTH_MODE:                  ${AUTH_MODE}
SSL:                        ${SSL}
IAM_CREDENTIALS_PROVIDER:   ${IAM_CREDENTIALS_PROVIDER}
AWS_REGION:                 ${AWS_REGION}"

/home/ec2-user/anaconda3/envs/JupyterSystemEnv/bin/python -m graph_notebook.configuration.generate_config \
  --host "${HOST}" \
  --port "${PORT}" \
  --auth_mode "${AUTH_MODE}" \
  --ssl "${SSL}" \
  --iam_credentials_provider "${IAM_CREDENTIALS_PROVIDER}" \
  --load_from_s3_arn "${LOAD_FROM_S3_ARN}" \
  --aws_region "${AWS_REGION}"

chmod u+rwx ~/graph_notebook

mkdir -p ~/SageMaker/Neptune
cp -r ~/graph_notebook/src/graph_notebook/notebook/* ~/SageMaker/Neptune
chmod -R a+rw ~/SageMaker/Neptune/*

source /home/ec2-user/anaconda3/bin/deactivate