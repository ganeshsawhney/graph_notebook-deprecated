export * from "./version";
export * from "./force_widget";

if (module.hot) {
  module.hot.accept(function () {
    console.log("new module failed");
  });
}
