def escape_reserved_characters(content: str):
    return content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
